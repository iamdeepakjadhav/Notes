import java.sql.*;

public class ConnectionProvider {
    private static Connection con;
//
//    public static void main(String[] args){
//        try{
//            if(con == null){
//                // create a connection to jdbc
//                // 1. load driver
//                Class.forName("com.mysql.cj.jdbc.Driver");
//
//                // 2. create a connection
//                String url = "jdbc:mysql://localhost/banking_system";
//                String userName = "root";
//                String password = "root";
//
//                con = DriverManager.getConnection(url, userName, password);
////                Statement statement = con.createStatement();
////
////                ResultSet resultSet = statement.executeQuery("SELECT * FORM accounts");
////
////                while(resultSet.next()){
////                    System.out.println(resultSet.getString("full_name"));
////                }
//
//                System.out.println("Done........");
//
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//    }

}
