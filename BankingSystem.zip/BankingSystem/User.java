import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class User {
    private Connection connection;
    private BufferedReader br ;

    public User(Connection con, BufferedReader br) {
        this.connection = con;
        this.br = br;
    }

    public void register() throws IOException {
        System.out.print("Full Name : ");
        String full_name = br.readLine();
        System.out.print("Email : ");
        String email = br.readLine();
        System.out.print("Password : ");
        String password = br.readLine();
        if (user_exist(email)){
            System.out.println("User Already Exists for this Email Address!!");
            return;
        }
        String register_query = "INSERT INTO User(full_name,email,password) VALUES(?,?,?)";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(register_query);
            preparedStatement.setString(1, full_name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3,password);
            int affectedRow = preparedStatement.executeUpdate();
            if (affectedRow>0){
                System.out.println("Registration Successfull!");
            }else{
                System.out.println("Registration failed!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String login() throws IOException{
        System.out.print("Email : ");
        String email = br.readLine();
        System.out.print("Password : ");
        String password = br.readLine();
        String login_query = "SELECT * FROM User WHERE email = ? AND password = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(login_query);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2,password);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                return email;
            }else {

                return null;
            }
        }catch (Exception e ) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean user_exist(String email){
        String query = "SELECT * FROM User Where email = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,email);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                return true;
            }else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}