import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

public class BankingApp {

    private static final String url = "jdbc:mysql://localhost/banking_system";
    private static final String userName = "root";
    private static final String password = "root";

    public static void main(String[] args) throws Exception { 

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }catch(Exception e){
            e.printStackTrace();
        }

        try {
            Connection con = DriverManager.getConnection(url,userName,password);
//            Scanner sc = new Scanner(System.in);
            InputStreamReader in = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(in);

            User user = new User(con , br);
            Accounts accounts = new Accounts(con, br);
            AccountManager accountManager = new AccountManager(con,br);

            String email;
            long account_number;

            while (true){
                String back = null;
                System.out.println("*** WELCOME TO BANKING SYSTEM ***");
                System.out.println();
                System.out.println("1. Register");
                System.out.println("2. Login");
                System.out.println("3. Exit");
                System.out.print("Enter your choice : ");
                int choice1 = Integer.parseInt(br.readLine());
                switch (choice1){
                    case 1:
                        user.register();
                        System.out.println("\033[H\033[2J");
                        System.out.flush();
                        break;
                    case 2:
                        email = user.login();
                        if (email != null){
                            System.out.println();
                            System.out.println("User Logged In!");
                            if (!accounts.account_exist(email)){
                                System.out.println();
                                System.out.print("1. Open a new Bank Account");
                                System.out.print("2. Exit");
                                if (Integer.parseInt(br.readLine()) == 1){
                                    account_number= accounts.open_account(email);
                                    System.out.println("Account Created Successfully");
                                    System.out.println("Your Account Number is : "+ account_number);
                                }else {
                                    break;
                                }

                            }
                            account_number= accounts.getAccountNumber(email);
                            int choice2 = 0;
                            while (choice2 != 5){
                                System.out.println();
                                System.out.println("1. Debit Money");
                                System.out.println("2. Credit Money");
                                System.out.println("3. Transfer Money");
                                System.out.println("4. Check Balance");
                                System.out.println("5. Log Out");
                                System.out.print("Enter Your Choice: ");
                                choice2 = Integer.parseInt(br.readLine());
                                switch(choice2){
                                    case 1:
                                        accountManager.debitMoney(account_number);
                                        break;
                                    case 2:
                                        accountManager.createMoney(account_number);
                                        break;
                                    case 3:
                                        accountManager.transferMoney(account_number);
                                        break;
                                    case 4:
                                        accountManager.getBalance(account_number);
                                        break;
                                    case 5:
                                        back = "back";
                                        System.out.println("Log Out Successfully...");
                                        break;
                                    default:
                                        System.out.println("Invalid choice...");
                                }
                            }
                        }else {
                            System.out.println("Invalid email ");
                            System.out.println();
                            break;
                        }
                    case 3:
                        if (back != null){
                            break;
                        }
                        System.out.println("THANK YOU FOR USING BANKING SYSTEM!!!");
                        System.out.println("Exiting System...!");
                        return;
                    default:
                        System.out.println("Enter valid choice..!");

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}