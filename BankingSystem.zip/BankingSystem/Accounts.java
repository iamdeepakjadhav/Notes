import javax.imageio.spi.RegisterableService;
import java.io.BufferedReader;
import java.sql.*;

/**
 * Accounts
 */
public class Accounts {

    private Connection connection;
    private BufferedReader br ;

    public Accounts(Connection con, BufferedReader br) {
        this.connection = con;
        this.br = br;
    }

    public long open_account(String email) throws Exception {
        if (!account_exist(email)){
            String open_account_query = "INSERT INTO Accounts(account_number,full_name,email,balance,security_pin) VALUES(?,?,?,?,?)";
            System.out.print("Enter Full Name : ");
            String full_name = br.readLine();
            System.out.print("Enter Initial Amount : ");
            double balance = Double.parseDouble(br.readLine());
            System.out.print("Enter Security Pin : ");
            String security_pin = br.readLine();
            try{
                long account_number  =generateAccountNumber();
                PreparedStatement preparedStatement = connection.prepareStatement(open_account_query);
                preparedStatement.setLong(1, account_number);
                preparedStatement.setString(2, full_name);
                preparedStatement.setString(3, email);
                preparedStatement.setDouble(4, balance);
                preparedStatement.setString(5, security_pin);
                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0){
                    return account_number;
                }else {
                    throw new RuntimeException("Account Creation failed!!");

                }
            }catch (Exception e){
                e.printStackTrace();
            }

        }
        throw new RuntimeException("Account Already Exist....");
    }

    public long getAccountNumber(String email){
        String query = "SELECT account_number from Accounts WHERE email = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                return resultSet.getLong("account_number");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        throw  new RuntimeException("Account Number Doesn't Exist!");
    }

    public long generateAccountNumber(){
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT account_number from Accounts ORDER BY account_number DESC LIMIT 1 ");
            if (resultSet.next()){
                long last_account_number = resultSet.getLong("account_number");
                return last_account_number+1;
            }else {
                return 10000100;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return 10000100;
    }

    public boolean account_exist(String email){
        String query = "SELECT account_number from Accounts WHERE email = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1,email);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                return true;
            }else{
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}